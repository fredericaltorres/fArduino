[![endorse](http://api.coderwall.com/tylermenezes/endorsecount.png)](http://coderwall.com/tylermenezes)

This project is no longer maintained because my Rfid reader exploded (srsly).