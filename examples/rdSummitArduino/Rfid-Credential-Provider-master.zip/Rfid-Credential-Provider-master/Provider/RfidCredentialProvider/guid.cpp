#include <initguid.h>
#include "guid.h"